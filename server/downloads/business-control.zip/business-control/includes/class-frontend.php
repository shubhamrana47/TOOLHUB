<?php

if (!defined('ABSPATH')) {
    exit;
}

class wpai_business_control_Frontend {

    /**
     * Constructor.
     */

    public function __construct() {

        add_shortcode(
            'business-control',
            array(
                $this,
                'shortcode'
            )
        );

    }

    /**
     * Shortcode.
     */

    public function shortcode(
        $atts = array(),
        $content = null
    ) {

        ob_start();

        ?>

        <div
            class="business-control"
            data-plugin="business-control"
        >

            <div class="business-control-box">

                <h3>
                    Business Control
                </h3>

                <p>
                    Your custom WordPress plugin
                    is working successfully.
                </p>

            </div>

        </div>

        <?php

        return ob_get_clean();
    }
}

new wpai_business_control_Frontend();
