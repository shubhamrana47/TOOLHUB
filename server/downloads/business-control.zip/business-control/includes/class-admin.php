<?php

if (!defined('ABSPATH')) {
    exit;
}

class wpai_business_control_Admin {

    /**
     * Constructor.
     */

    public function __construct() {

        add_action(
            'admin_menu',
            array(
                $this,
                'admin_menu'
            )
        );

    }

    /**
     * Add admin menu.
     */

    public function admin_menu() {

        add_menu_page(
            'Business Control',
            'Business Control',
            'manage_options',
            'business-control',
            array(
                $this,
                'admin_page'
            ),
            'dashicons-admin-generic',
            25
        );

    }

    /**
     * Admin page.
     */

    public function admin_page() {

        if (!current_user_can('manage_options')) {
            return;
        }

        ?>

        <div class="wrap">

            <h1>
                Business Control
            </h1>

            <div class="notice notice-success">

                <p>
                    Plugin is installed and working successfully.
                </p>

            </div>

            <div class="card">

                <h2>
                    Plugin Requirement
                </h2>

                <p>
                    Create a business control WordPress plugin with an admin dashboard for managing business records, settings and reports.
                </p>

            </div>

            <div class="card">

                <h2>
                    Included Features
                </h2>

                <ul>

                    <li>✓ Admin Dashboard</li>
<li>✓ Database</li>
<li>✓ Settings Page</li>

                </ul>

            </div>

        </div>

        <?php
    }
}

new wpai_business_control_Admin();
