=== Business Control ===

Contributors: wp-ai-builder

Tags: wordpress, plugin, ai

Requires at least: 5.8

Tested up to: 6.9

Requires PHP: 7.4

Stable tag: 1.0.0

License: GPLv2 or later

License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Create a business control WordPress plugin with an admin dashboard for managing business records, settings and reports.

This plugin was generated using WP AI Builder.

== Features ==

- Admin Dashboard
- Database
- Settings Page

== Installation ==

1. Download the plugin ZIP.
2. Go to WordPress Dashboard.
3. Open Plugins > Add New Plugin.
4. Click Upload Plugin.
5. Select the ZIP file.
6. Install and activate the plugin.

== Usage ==

Use the shortcode:

[business-control]

== Version ==

1.0.0
