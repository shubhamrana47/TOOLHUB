document.addEventListener(
    "DOMContentLoaded",
    function () {

        console.log(
            "Business Control loaded successfully."
        );

    }
);
