<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

/**
 * Plugin cleanup code.
 *
 * Add database cleanup here if required.
 */
