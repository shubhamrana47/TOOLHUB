<?php

/**
 * Plugin Name: Business Control
 * Plugin URI: https://example.com/
 * Description: AI generated WordPress plugin.
 * Version: 1.0.0
 * Author: WP AI Builder
 * Author URI: https://example.com/
 * License: GPL-2.0-or-later
 * Text Domain: business-control
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Plugin constants.
 */

define(
    'WPAI_BUSINESS_CONTROL_VERSION',
    '1.0.0'
);

define(
    'WPAI_BUSINESS_CONTROL_PATH',
    plugin_dir_path(__FILE__)
);

define(
    'WPAI_BUSINESS_CONTROL_URL',
    plugin_dir_url(__FILE__)
);

/**
 * Plugin initialization.
 */

function wpai_business_control_init() {

    // Plugin initialization code.

}

add_action(
    'plugins_loaded',
    'wpai_business_control_init'
);

/**
 * Load admin functionality.
 */

require_once
    WPAI_BUSINESS_CONTROL_PATH .
    'includes/class-admin.php';

/**
 * Load frontend functionality.
 */

require_once
    WPAI_BUSINESS_CONTROL_PATH .
    'includes/class-frontend.php';

/**
 * Enqueue plugin assets.
 */

function wpai_business_control_assets() {

    wp_enqueue_style(
        'business-control-style',
        WPAI_BUSINESS_CONTROL_URL .
        'assets/css/style.css',
        array(),
        WPAI_BUSINESS_CONTROL_VERSION
    );

    wp_enqueue_script(
        'business-control-script',
        WPAI_BUSINESS_CONTROL_URL .
        'assets/js/script.js',
        array('jquery'),
        WPAI_BUSINESS_CONTROL_VERSION,
        true
    );

}

add_action(
    'wp_enqueue_scripts',
    'wpai_business_control_assets'
);

add_action(
    'admin_enqueue_scripts',
    'wpai_business_control_assets'
);
